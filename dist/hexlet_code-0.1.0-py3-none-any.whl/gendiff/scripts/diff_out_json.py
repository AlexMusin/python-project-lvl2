import json

def out_json(inp_diff):
    return json.dumps(inp_diff, indent=2)
